package com.example.weighttrackingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class MainActivity extends AppCompatActivity {

    public String currentUsername;

    //view components
    Button loginButton;
    Button createAccount;
    Button resetButton;
    DBHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setting view to activity main layout
        setContentView(R.layout.activity_main);
        //new database handler instance
        db = new DBHandler(this);

        //assigning variables to layout components
        EditText usernameEditText = findViewById(R.id.usrName);
        EditText passwordEditText = findViewById(R.id.passWord);

        //assigning button to view component with click listener
        loginButton = findViewById(R.id.log_on);
        loginButton.setOnClickListener(v -> {
            //retrieving text from username and password fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();
            //hashing password for security -> md5 is one way therefore we can compare the resulting hash to the hash stored in the database
            password = md5(password);
            submitCred(db.getCred(username, password), username); //function to verify login credentials
        });

        //assigning button click listener to create account button
        createAccount = findViewById(R.id.createActBtn);
        createAccount.setOnClickListener(view -> {
            //instantiating new Alert Dialog on click
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            //creating view with layout of create account xml resource
            View createAccount  = getLayoutInflater().inflate(R.layout.dialog_create_account, null);
            //declaring and assigning edit text fields, button within xml layout
            EditText newUsername = createAccount.findViewById(R.id.enterUser);
            EditText newPassword = createAccount.findViewById(R.id.enterPass);
            Button saveUsrBtn = createAccount.findViewById(R.id.saveNewCred);

            //building dialog with custom layout
            dialog.setView(createAccount);
            //create and show new dialog
            AlertDialog mDialog = dialog.create();
            dialog.show();

            //on click listener for button in alert dialog
            saveUsrBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //retrieving text fields
                    String username = newUsername.getText().toString();
                    String password = newPassword.getText().toString();
                    //hashing password
                    password = md5(password);
                    //checking that password has a value
                    if(!password.equals("")) {
                        //new User model with username and password
                        User user = new User(username, password);
                        //adding user to the database, returns true if successful
                        if(!db.addUser(user)) {
                            //code executes if addUser is unsuccessful thus the method found an existing username
                            Context context = getApplicationContext();
                            CharSequence text = "Username Already Exists";
                            int duration = Toast.LENGTH_SHORT;

                            //showing toast informing user that username exists
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        } else {
                            //if adduser is successful, toast display account creation result
                            Context context = getApplicationContext();
                            CharSequence text = "Account Successfully Created. Login with New Account";
                            int duration = Toast.LENGTH_SHORT;

                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        }
                    }
                    //dismiss alert dialog
                    mDialog.dismiss();
                }
            });
        });

        //creating on click listener for reset password button
        resetButton = findViewById(R.id.resetPwdBtn);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //retrieving text fields
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                password = md5(password);
                //identical logic to addUser but with updateUser function instead
                if(!password.equals("")) {
                    if(!db.updateUser(username, password)) {
                        Context context = getApplicationContext();
                        CharSequence text = "Password Reset Failed";
                        int duration = Toast.LENGTH_SHORT;

                        //display failure result
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    } else {
                        Context context = getApplicationContext();
                        CharSequence text = "Password Reset";
                        int duration = Toast.LENGTH_SHORT;

                        //display successful result
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            }
        });
    }

    //method to identify valid credential result and transition to next activity (app home screen)
    private void submitCred(boolean cred, String username) {
        if(cred) {
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            currentUsername = username;
        } else {
            Context context = getApplicationContext();
            CharSequence text = "Incorrect Username or Password";
            int duration = Toast.LENGTH_SHORT;

            //displays invalid credentials result
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

    //hashing function
    public String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i=0; i<messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }



}