package com.example.weighttrackingapp;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//info screen fragment
public class InfoFragment extends Fragment implements InfoCardAdapter.OnSelectListener {

    //database components
    DBHandler db;
    List<Weight> dataList;
    Weight weight;
    InfoCardAdapter adapter;

    //holds adapter position
    int position;

    //default constructor
    public InfoFragment() {

    }

    //implements onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_info, container, false);
        setHasOptionsMenu(true);
        //creates recyclerView layout and attaches to layout component
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        RecyclerView rvWeight = v.findViewById(R.id.rvWeight);

        //try catch block to execute recyclerview functionality
        try {
            //new database handler
            db = new DBHandler(getActivity());
            //putting all database data to list sorted by date
            dataList = db.getAllDataByDate();
            //plugging list information into view adapter
            adapter = new InfoCardAdapter(dataList,  this);
            //sets adapter, layoutManager
            rvWeight.setAdapter(adapter);
            rvWeight.setLayoutManager(layoutManager);
            registerForContextMenu(rvWeight);
        }
        catch(NullPointerException e) {
            Toast.makeText(getContext(), "No Information to Show", Toast.LENGTH_SHORT).show();
        }

        return v;
    }


    //implements onSelectClick
    @Override
    public void onSelectClick(View itemView, int position) {
        //gets weight by using the date from the position index in the list
        this.position = position;
        weight = db.getData(dataList.get(position).getDate());
    }
}
