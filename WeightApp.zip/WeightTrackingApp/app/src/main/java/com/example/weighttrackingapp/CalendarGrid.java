package com.example.weighttrackingapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

//class for child fragment to create a custom calendar
public class CalendarGrid extends Fragment {

    //hash map with date key and string value
    HashMap<LocalDate, String> currentCalendar = new HashMap<>();
    DBHandler db;

    //implements onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.calendar, container, false);
        //new database handler
        db = new DBHandler(getActivity());

        //calling builder methods with respect to view v
        createCalendar(v);
        AddWeightToCalendar(v);

        return v;
    }

    //initializes calendar based on current date and creates hashmap
    /*
    method summary
    -iterates through days of month starting w/ first day of current month
    -depending on which day of the week the first of the month is there is a slightly different for loop to populate all "days" TextViews in GridView
    -concats i onto string day giving the id of the textview components
    -retrieves resource id using new day string and package information
    -assigns instance of textview to resource id
    -method then checks if i is before the 1st of the month or after the last of the month
    -calculates and places correct day of the month for each grid cell
    -puts the corresponding date and component id into the hashmap for other method in scope
    -updates textsize and resets string day
     */
    @SuppressLint("SetTextI18n")
    public void createCalendar(View v) {
        String day = "day";
        LocalDate currentDate = LocalDate.now();
        LocalDate firstOfMonth = currentDate.withDayOfMonth(1);
        TextView calDay;
        int j = 1;
        int h = 1;


        switch (firstOfMonth.getDayOfWeek()) {
            case SUNDAY:
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case MONDAY:
                j = 1;
                h = 1;
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i == 1) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(currentDate.minusMonths(1).lengthOfMonth()), day);
                        calDay.setText(Integer.toString(firstOfMonth.minusMonths(1).lengthOfMonth()));
                    } else if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                        h++;
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case TUESDAY:
                j = 1;
                int k = firstOfMonth.minusMonths(1).lengthOfMonth();
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i <= 2) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(k), day);
                        calDay.setText(Integer.toString(k));
                        k--;
                    } else if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case WEDNESDAY:
                j = 1;
                k = firstOfMonth.minusMonths(1).lengthOfMonth();
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i <= 3) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(k), day);
                        calDay.setText(Integer.toString(k));
                        k--;
                    } else if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case THURSDAY:
                j = 1;
                k = firstOfMonth.minusMonths(1).lengthOfMonth();
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i <= 4) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(k), day);
                        calDay.setText(Integer.toString(k));
                        k--;
                    } else if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case FRIDAY:
                j = 1;
                h = 1;
                k = firstOfMonth.minusMonths(1).lengthOfMonth() - 4;
                for(int i = 1; i <= 42; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i <= 5) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(k), day);
                        calDay.setText(Integer.toString(k));
                        k++;
                    } else if(h > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(h), day);
                        calDay.setText(Integer.toString(h));
                        h++;
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
            case SATURDAY:
                j = 1;
                k = firstOfMonth.minusMonths(1).lengthOfMonth();
                for(int i = 1; i <= 35; i++) {
                    day = day.concat(Integer.toString(i));
                    int resID = getResources().getIdentifier(day, "id", getActivity().getPackageName());
                    calDay = v.findViewById(resID);
                    if(i <= 6) {
                        currentCalendar.put(currentDate.minusMonths(1).withDayOfMonth(k), day);
                        calDay.setText(Integer.toString(k));
                        k--;
                    } else if(i > firstOfMonth.lengthOfMonth()) {
                        currentCalendar.put(currentDate.plusMonths(1).withDayOfMonth(j), day);
                        calDay.setText(Integer.toString(j));
                        j++;
                    } else {
                        currentCalendar.put(currentDate.withDayOfMonth(i), day);
                        calDay.setText(Integer.toString(i));
                    }
                    calDay.setTextSize(10);
                    day = "day";
                }
                break;
        }
    }

    //invoked when weight is added -> displays new measurement on calendar as long as date is in hashmap
    public void AddWeightToCalendar(View v) {
        LocalDate date;
        //gets all values in weight table of database
        List<Weight> dataList = db.getAllData();
        String mDate;
        TextView dayWeight;
        String w;

        //iterates through list and checks if there is a weight value on a date within the current calendar
        for (int i = 0; i < dataList.size(); i++) {
            mDate = dataList.get(i).getDate();
            mDate = mDate.replace('/', '-');
            //filtering input to avoid exceptions -> ISO date format yyyy-mm-dd
            if(mDate.charAt(2) == '-') {
                mDate = "2011-12-03";
            }
            date = LocalDate.parse(mDate);
            if(currentCalendar.containsKey(date)) {
                //replaces characters "day" with "w" corresponding to correct component id in gridView
                w = currentCalendar.get(date).replace("day", "w");
                int resID = getResources().getIdentifier(w, "id", getActivity().getPackageName());
                dayWeight = v.findViewById(resID);
                dayWeight.setText(Double.toString(dataList.get(i).getWeight()));
                dayWeight.setTextSize(10);
            }
        }
    }
}
