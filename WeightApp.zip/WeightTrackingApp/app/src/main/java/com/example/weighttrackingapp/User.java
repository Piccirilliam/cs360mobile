package com.example.weighttrackingapp;

//User model for database
public class User {

    //database values
    int _id;
    String _username;
    String _password;

    //constructors
    public User () {

    }

    public User(int id, String username, String password) {
        this._id = id;
        this._username = username;
        this._password = password;
    }

    public User(String username, String password) {
        this._username = username;
        this._password = password;
    }

    //setters
    public void setID(int id) { this._id = id; }

    public void setUsername(String username) { this._username = username; }

    public void setPassword(String password) { this._password = password; }


    //getters
    public long getID() {return this._id;}

    public String getUsername() {return this._username;}

    public String getPassword() {return this._password;}
}
