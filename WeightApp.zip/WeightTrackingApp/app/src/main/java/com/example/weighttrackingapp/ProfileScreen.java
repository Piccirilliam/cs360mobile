package com.example.weighttrackingapp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.switchmaterial.SwitchMaterial;



public class ProfileScreen extends Fragment {

    //permission codes
    private static final int SMS_PERMISSION_CODE = 100;
    private static final int PHONE_PERMISSION_CODE = 101;
    private static final int READ_PHONE_PERMISSION_CODE = 102;

    //layout components
    DBHandler db;
    TextView mHello;
    TextView mViewGoalType;

    //default constructor
    public ProfileScreen() {

    }

    //implements onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        //new database handler
        db = new DBHandler(getActivity());

        //matching layout components to variables
        mHello = v.findViewById(R.id.hello);
        mViewGoalType = v.findViewById(R.id.viewGoal);

        //Displays the current user while encouraging to continue towards goal
        mHello.setText(getString(R.string.hello) + " " + db.getCurrentUser().getUsername());
        if(db.getGoalAndType().get(db.getGoalAndType().size()-1).getGoalType() == 1) {
            mViewGoalType.setText(R.string.viewGoal2);
        } else {
            mViewGoalType.setText(R.string.viewGoal1);
        }

        return v;
    }

    //implements onViewCreated
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //new database handler
        db = new DBHandler(getActivity());

        //attaching material switch button to variable with onCheckedChangeListener
        SwitchMaterial permissions = view.findViewById(R.id.enable_sms);
        permissions.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                //if toggle is true
                if(b) {
                    //check for READ_PHONE_NUMBERS permission and SEND_SMS permission
                    if(ContextCompat.checkSelfPermission(getActivity(),
                            Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED &&
                            ContextCompat.checkSelfPermission(getActivity(),
                                    Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(getContext(), "Permission Previously Granted", Toast.LENGTH_SHORT).show(); //informs user permissions are granted
                    } else {
                        //if permissions not granted -> checks if permission rationale should show
                        if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.READ_PHONE_NUMBERS)) {
                            //alert dialog explains which permission is needed and why
                            new AlertDialog
                                    .Builder(getActivity())
                                    .setTitle("Phone Permission Needed")
                                    .setMessage("This permission is needed to notify the user when their goal weight is reached")
                                    //button listeners for Ok and Cancel. Ok requests permission
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.READ_PHONE_NUMBERS}, PHONE_PERMISSION_CODE);
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();
                                        }
                                    })
                                    .create().show();
                        } else {
                            //request READ_PHONE_NUMBERS permission
                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.READ_PHONE_NUMBERS}, PHONE_PERMISSION_CODE);
                        }

                        //identical logic checking for SEND_SMS permission
                        if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.SEND_SMS)) {
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Text Permission Needed")
                                    .setMessage("This permission is needed to notify the user when their goal weight is reached")
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();
                                        }
                                    })
                                    .create().show();
                        } else {
                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                        }

                        //identical logic checking for READ_PHONE_STATE permission
                        if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.READ_PHONE_STATE)) {
                            new AlertDialog.Builder(getActivity())
                                    .setTitle("Text Permission Needed")
                                    .setMessage("This permission is needed to notify the user when their goal weight is reached")
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.READ_PHONE_STATE}, READ_PHONE_PERMISSION_CODE);
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();
                                        }
                                    })
                                    .create().show();
                        } else {
                            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.READ_PHONE_STATE}, READ_PHONE_PERMISSION_CODE);
                        }
                    }
                }
            }
        });
    }

    //implements requestPermissionResult
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //checks that request code is equal to one of permission codes
        if(requestCode == PHONE_PERMISSION_CODE || requestCode == SMS_PERMISSION_CODE || requestCode == READ_PHONE_PERMISSION_CODE) {
            //if permission is granted toast displays
            if( grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}




