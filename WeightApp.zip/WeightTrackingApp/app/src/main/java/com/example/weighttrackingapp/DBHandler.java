package com.example.weighttrackingapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    //logcat tag
    private static final String LOG = "DBHandler";

    //db version
    private static final int DB_VERSION = 1;

    //db name
    private static final String DB_NAME = "app_db";

    //table names
    private static final String TABLE_WEIGHT = "weightTracker";
    private static final String TABLE_USR = "users";
    private static final String TABLE_GOAL = "goalsettings";

    //common column names
    private static final String KEY_ID = "id";

    //weight table
    private static final String DATE_COL = "date";
    private static final String WEIGHT_COL = "weight";

    //user table
    private static final String USRNME_COL = "username";
    private static final String PWD_COL = "password";

    //goal table
    private static final String GOAL_COL = "goal";
    private static final String GTYPE_COL = "goaltype";

    //creating SQLite tables
    private static final String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + " ("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + DATE_COL + " TEXT,"
            + WEIGHT_COL + " REAL)";

    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USR + " ("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + USRNME_COL + " TEXT NOT NULL UNIQUE,"
            + PWD_COL + " TEXT)";

    private static final String CREATE_GOAL_TABLE = "CREATE TABLE " + TABLE_GOAL + " ("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + GTYPE_COL + " INTEGER,"
            + GOAL_COL + " REAL)";


    //constructor
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    //creates tables within database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_WEIGHT_TABLE);
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_GOAL_TABLE);
    }

    //creates new table if newer database version
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USR);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);

        //create new tables
        onCreate(db);
    }

    //adds user to database users table
    public boolean addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(USRNME_COL, user.getUsername());
        values.put(PWD_COL, user.getPassword());

        //SQLite query
        Cursor cursor = db.query(TABLE_USR, new String[] {KEY_ID, USRNME_COL, PWD_COL}, USRNME_COL + "=?",
                new String[] {user.getUsername()}, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
            db.insert(TABLE_USR, null, values);
            db.close();
            cursor.close();
            return true;
        } else {
            db.close();
            return false;
        }

    }

    //returns true or false depending on whether username and password match database values
    public boolean getCred(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_USR, new String[] {KEY_ID, USRNME_COL, PWD_COL}, USRNME_COL + "=?",
                new String[] {username}, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            if(password.equals(cursor.getString(2))) {
                cursor.close();
                return true;
            } else {
                cursor.close();
                return false;
            }
        }
        return false;
    }

    //updates user data based on username and new password
    public boolean updateUser(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(USRNME_COL, username);
        values.put(PWD_COL, newPassword);

        try {
            db.update(TABLE_WEIGHT, values, KEY_ID + " =?", new String[] {String.valueOf(username)});
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }


    //adds new goal model to database and writes to goal table
    public void addGoalWeight(Goal goal) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(GTYPE_COL, goal.getGoalType());
        values.put(GOAL_COL, goal.getGoalWeight());

        db.insert(TABLE_GOAL, null, values);
        db.close();
    }

    //adds weight model to weight table in database
    public void addWeight(Weight weight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values =  new ContentValues();

        values.put(DATE_COL, weight.getDate());
        values.put(WEIGHT_COL, weight.getWeight());


        db.insert(TABLE_WEIGHT, null, values);

        db.close();
    }

    //gets the most recent user values by limited query results to 1, returns user model
    User getCurrentUser() {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLE_USR + " LIMIT " + 1;

        Cursor cursor = db.rawQuery(selectQuery, null);
        if(cursor != null)
            cursor.moveToFirst();

        @SuppressLint("Range") User usr = new User(cursor.getString(cursor.getColumnIndex(USRNME_COL)), cursor.getString(cursor.getColumnIndex(PWD_COL)));

        cursor.close();

        return usr;
    }

    //gets data from provided date and returns weight model
    Weight getData(String date) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_WEIGHT, new String[] {KEY_ID, DATE_COL, WEIGHT_COL}, DATE_COL + "=?",
                new String[] {String.valueOf(date)}, null, null, null, null);

        if(cursor != null)
            cursor.moveToFirst();

        Weight weight = new Weight(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), Double.parseDouble(cursor.getString(2)));

        cursor.close();

        return weight;
    }

    //gets all data in the weight table and exports to a list of weight models
    public List<Weight> getAllData() {
        List<Weight> dataList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_WEIGHT;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setID(Integer.parseInt(cursor.getString(0)));
                weight.setDate(cursor.getString(1));
                weight.setWeight(Double.parseDouble(cursor.getString(2)));

                dataList.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dataList;
    }

    //method is identical to getAllData() except query sorts by data in descending order
    public List<Weight> getAllDataByDate() {
        List<Weight> dataList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_WEIGHT + " ORDER BY " + DATE_COL + " DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setID(Integer.parseInt(cursor.getString(0)));
                weight.setDate(cursor.getString(1));
                weight.setWeight(Double.parseDouble(cursor.getString(2)));

                dataList.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dataList;
    }

    //exports all goal models from goal table in database
    public List<Goal> getGoalAndType() {
        List<Goal> dataList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_GOAL;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()) {
            do {
                Goal goal = new Goal();
                goal.setGoalType(Integer.parseInt(cursor.getString(0)));
                goal.setGoalWeight(Double.parseDouble(cursor.getString(1)));

                dataList.add(goal);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dataList;
    }

    //method updates existing database entry with new weight model
    public int editData(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DATE_COL, weight.getDate());
        values.put(WEIGHT_COL, weight.getWeight());

        return db.update(TABLE_WEIGHT, values, KEY_ID + " =?", new String[] {String.valueOf(weight.getID())});
    }

    //method deletes entry matching provided weight model
    public void deleteEntry(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT, KEY_ID + " =?", new String[] {String.valueOf(weight.getID())});
        db.close();
    }



}
