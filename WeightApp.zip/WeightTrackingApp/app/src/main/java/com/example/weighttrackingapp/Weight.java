package com.example.weighttrackingapp;

//Weight model for database
public class Weight {

    //database values
    int _id;
    String _date;
    double _weight;

    //constructors
    public Weight() {}

    public Weight(int id, String date, double weight) {
        this._id = id;
        this._date = date;
        this._weight = weight;
    }

    public Weight(String date, double weight) {
        this._weight = weight;
        this._date = date;
    }

    //setters
    public void setID(int id) {
        this._id = id;
    }

    public void setWeight(double weight) {
        this._weight = weight;
    }

    public void setDate(String date) {
        this._date = date;
    }

    //getters
    public double getWeight() {
        return this._weight;
    }

    public long getID() {
        return this._id;
    }

    public String getDate() {
        return this._date;
    }


}
