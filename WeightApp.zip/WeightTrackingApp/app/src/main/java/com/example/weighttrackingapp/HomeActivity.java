package com.example.weighttrackingapp;


import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class HomeActivity extends AppCompatActivity  {

    //bottom navigation bar
    BottomNavigationView bottomNavigationView;


    //fragments for each app screen
    ProfileScreen profileScreen = new ProfileScreen();
    CalendarScreen calendarScreen = new CalendarScreen();
    InfoFragment infoFragment = new InfoFragment();


    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setting view to home activity layout
        setContentView(R.layout.activity_home);

        //logic for bottom nav fragment manager
        bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            //switch statement with respect to menu item ID
            switch (item.getItemId()) {
                case R.id.action_profile: //profile screen
                    getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, profileScreen).commit();
                    return true;
                case R.id.action_home: //home (calendar) screen
                    getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, calendarScreen).commit();
                    return true;
                case R.id.action_info: //details screen
                    getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, infoFragment).commit();
                    return true;
            }

            return false;
        });
    }
}