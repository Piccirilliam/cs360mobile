package com.example.weighttrackingapp;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//adapter class for recyclerview
public class InfoCardAdapter extends RecyclerView.Adapter<InfoCardAdapter.ViewHolder> {

    //list to hold values and onSelectListener
    private OnSelectListener mOnSelectListener;
    private List<Weight> dataList;
    private List<Goal> goalList;

    //view holder for recyclerview
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        //declaring layout components
        public TextView cDate;
        public TextView cWeight;
        public TextView cDiff;
        public ImageView cImg;
        public RelativeLayout relativeLayout;
        OnSelectListener onSelectListener;
        DBHandler db;

        //implements ViewHolder
        public ViewHolder(View itemView, OnSelectListener onSelectListener) {
            super(itemView);

            //attaches layout components to variables
            cDate = itemView.findViewById(R.id.infoDate);
            cWeight = itemView.findViewById(R.id.infoWeight);
            cDiff = itemView.findViewById(R.id.infoProgress);
            cImg = itemView.findViewById(R.id.imageView);
            relativeLayout = itemView.findViewById(R.id.relativeCard);
            this.onSelectListener = onSelectListener;
            db = new DBHandler(itemView.getContext());
            goalList = db.getGoalAndType();

            itemView.setOnClickListener(this);
        }
            //retrieves which card was selected and calls dialog method
            @Override
            public void onClick(View view) {
                onSelectListener.onSelectClick(view, getAdapterPosition());
                createOptionsDialog();
            }

            //dialog builder method
            public void createOptionsDialog() {
                AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
                //sets options array as DialogInterface with two options (edit or delete)
                builder.setItems(R.array.options_array, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                switch (i) {
                                    case 0:
                                        //method call to update entry data
                                        enterNewWeight();
                                    case 1:
                                        //deletes entry from instance of Weight model in list at adapter position
                                        db.deleteEntry(dataList.get(getAdapterPosition()));
                                }
                            }
                        });
                //shows dialog
                builder.show();

            }

            //method to enter and update entry data
            public void enterNewWeight() {

                //new dialog builder
                AlertDialog.Builder dialog = new AlertDialog.Builder(itemView.getContext());
                //creating inflator from system service
                LayoutInflater inflater = (LayoutInflater) itemView.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                //assign inflated layout to view
                View customDialog = inflater.inflate(R.layout.dialog_options, null);
                //create dialog from view
                dialog.setView(customDialog)
                        .setTitle(R.string.newWeight)
                        //button to save new data
                        .setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //retrieves text fields
                                String date = dataList.get(getAdapterPosition()).getDate();
                                EditText newW = customDialog.findViewById(R.id.newWeight);
                                String mWeight = newW.getText().toString();
                                //creates new weight model and updates database using editData()
                                Weight editEntry = new Weight(date, Double.parseDouble(mWeight));
                                db.editData(editEntry);
                            }
                        });
                dialog.show();

            }

        }


        //list adapter
    public InfoCardAdapter(List<Weight> weights, OnSelectListener onSelectListener) {
        dataList = weights;
        this.mOnSelectListener = onSelectListener;
    }

    //implements onCreateViewHolder
    @Override
    public InfoCardAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        //inflator from context -> parent.getContext()
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View infoView = inflater.inflate(R.layout.info_card, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(infoView, mOnSelectListener);
        return viewHolder;
    }

    //implements onBindViewHolder
    @Override
    public void onBindViewHolder(InfoCardAdapter.ViewHolder holder, int position) {
        // Get the data model based on position
        Weight weight = dataList.get(position);
        ImageView imageView = holder.cImg;
        String pounds = " Lbs";

        // Set item views based on your views and data model
        TextView textView = holder.cDate;
        textView.setText(weight.getDate());

        TextView textView1 = holder.cWeight;
        textView1.setText(Double.toString(weight.getWeight()) + pounds);

        TextView textView2 = holder.cDiff;
        //checks if there is a prior measurement for comparison
        if(position == dataList.size() - 1) {
            textView2.setText(R.string.noPrior);
        } else {
            //calculates weight difference for each card in descending order of date
            textView2.setText(Double.toString(weight.getWeight() - dataList.get(position + 1).getWeight()) + pounds);
            if(goalList.size() > 0) {
                if(weight.getWeight() - dataList.get(position + 1).getWeight() >= 0) {
                    //sets icons to different color depending on goal type
                    if(goalList.get(goalList.size()-1).getGoalType() == 0) {
                        imageView.setImageResource(R.drawable.ic_round_trending_up_24);
                    } else {
                        imageView.setImageResource(R.drawable.ic_round_trending_up_24_green);
                    }
                } else {
                    if(goalList.get(goalList.size()-1).getGoalType() == 0) {
                        imageView.setImageResource(R.drawable.ic_round_trending_down_24);
                    }
                    else {
                        imageView.setImageResource(R.drawable.ic_round_trending_down_24_red);
                    }
                }
                //makes image visible
                imageView.setVisibility(View.VISIBLE);
            }
        }
    }



    //implements getItemCount
    @Override
    public int getItemCount() {
        return dataList.size();
    }

    //interface for fragment
    public interface OnSelectListener{
        void onSelectClick(View itemView, int position);
    }
}

