package com.example.weighttrackingapp;

//Goal model for database
public class Goal {

    //database values
    int _id;
    int _goalType;
    double _goalweight;

    //constructors
    public Goal() {

    }

    public Goal( int id, int goalType, double goalweight) {
        this._id = id;
        this._goalType = goalType;
        this._goalweight = goalweight;
    }

    public Goal(int goalType, double goalweight) {
        this._goalType = goalType;
        this._goalweight = goalweight;
    }

    //setters
    public void setID(int id) {this._id = id;}

    public void setGoalType(int goalType) {this._goalType = goalType;}

    public void setGoalWeight(double  goalweight) {this._goalweight = goalweight;}

    //getters
    public long getID() {return this._id;}

    public int getGoalType() {return this._goalType;}

    public double getGoalWeight() {return this._goalweight;}

}
