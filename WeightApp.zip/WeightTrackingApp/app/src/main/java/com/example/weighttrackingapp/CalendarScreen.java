package com.example.weighttrackingapp;


import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.radiobutton.MaterialRadioButton;

import java.time.LocalDate;
import java.util.List;


public class CalendarScreen extends Fragment {

    //view components
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private EditText newWeight, newDate, goalW;
    private Button saveBtn;
    private MaterialRadioButton btn1, btn2;

    //database models and handler
    Weight weight;
    Goal goal;
    DBHandler db;

    //default constructor
    public CalendarScreen() {

    }

    //fragment onCreateView implementation
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //creating view from inflated fragment layout
        View v = inflater.inflate(R.layout.fragment_calendar, container, false);

        //attaching view components to variables
        TextView currentW = v.findViewById(R.id.current_weight_txt);
        TextView goalW = v.findViewById(R.id.goal_weight_txt);
        TextView month = v.findViewById(R.id.textView4);
        //new database handler instance
        db = new DBHandler(getActivity());

        //retrieving current month
        month.setText(LocalDate.now().getMonth().toString());

        //try catch block to retrieve current weight
        //exception thrown if no weight measurements
        try {
            //assigning string values to textview
            currentW.setText(getString(R.string.curr_weight) + Double.toString(db.getAllData().get(db.getAllData().size() - 1).getWeight()));
        } catch (Exception e) {
            currentW.setText(getString(R.string.curr_weight) + getString(R.string.noWeight));
        }

        //try catch block to retrieve weight goal
        //exception thrown if no goal set
        try {
            List<Goal> dataList = db.getGoalAndType(); //getting goal and goal type from database
            if (dataList.get(dataList.size() - 1) != null) {
                //assigning string values to textview
                goalW.setText(getString(R.string.goal_weight) + Double.toString(dataList.get(dataList.size() - 1).getGoalWeight()));
            } else {
                goalW.setText(getString(R.string.goal_weight) + getString(R.string.noGoal));
            }

        } catch (Exception e) {
            goalW.setText(getString(R.string.goal_weight) + getString(R.string.noGoal));
        }

        //initializing floating action button with on click
        FloatingActionButton floatingActionButton = v.findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calling method to create new measurement on button press
                createNewWeightDialog();
            }

        });
        //calling method to send SMS if goal is achieved
        sendSMSMessage();
        return v;
    }

    //implements onViewCreated and calls function to insert a nested fragment
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        insertNestedFragment();
    }

    //inserts child fragment into current fragment view
    private void insertNestedFragment() {
        Fragment calendarGrid = new CalendarGrid();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        //sets layout to new instance of CalendarGrid
        transaction.replace(R.id.calendar_grid_fragment_container, calendarGrid).commit();

    }

    //method to create dialog to add new weight measurement
    public void createNewWeightDialog() {
        //declaring new Alert Dialog builder
        dialogBuilder = new AlertDialog.Builder(getContext());

        //declaring view with inflated layout of dialog_fab xml resource
        View addWeightView = getLayoutInflater().inflate(R.layout.dialog_fab, null);

        //assigning layout components to variables
        newWeight = addWeightView.findViewById(R.id.add_weight_measure);
        newDate = addWeightView.findViewById(R.id.msDate);
        saveBtn = addWeightView.findViewById(R.id.saveWeight);
        goalW = addWeightView.findViewById(R.id.goalWeightF);
        btn1 = addWeightView.findViewById(R.id.loseWeight);
        btn2 = addWeightView.findViewById(R.id.gainWeight);

        //if the user has already set their goal and goal type, those components will be hidden
        if(db.getGoalAndType().size() > 0) {
            goalW.setVisibility(View.GONE);
            btn1.setVisibility(View.GONE);
            btn2.setVisibility(View.GONE);
        }

        //creating and displaying new dialog
        dialogBuilder.setView(addWeightView);
        dialog = dialogBuilder.create();
        dialog.show();

        //button on click listener to save entry
        saveBtn.setOnClickListener(view -> {
            //retrieving EditText fields and placing in variables
            String nGoal = goalW.getText().toString();
            String nWeight = newWeight.getText().toString();
            String nDate = newDate.getText().toString();

            //checks if user would like to lose weight or gain weight
            if(btn1.isChecked()) {
                //ensures goal and type has been set and retrieves values of most current entry
                if(!db.getGoalAndType().isEmpty()) {
                    goal = new Goal(0, db.getGoalAndType().get(db.getGoalAndType().size() -1 ).getGoalWeight());
                } else {
                    //if they haven't been set, assigns new Goal model to database
                    goal = new Goal(0, Double.parseDouble(nGoal));
                }
            } else {
                //identical logic for users who want to gain weight
                if(!db.getGoalAndType().isEmpty()) {
                    goal = new Goal(1, db.getGoalAndType().get(db.getGoalAndType().size() -1 ).getGoalWeight());
                } else {
                    goal = new Goal(1, Double.parseDouble(nGoal));
                }
            }
            //new Weight model with data and weight measurement
            weight = new Weight(nDate, Double.parseDouble(nWeight));
            //adding goal and weight models to database with respective method calls
            db.addGoalWeight(goal);
            db.addWeight(weight);
            dialog.dismiss(); //closes alert dialog
        });
    }

    //method to send SMS message once goal has been met
    protected void sendSMSMessage() {
        //retrieving all values of goal and weight in database
        List<Goal> goalList = db.getGoalAndType();
        List<Weight> weightList = db.getAllData();

        //creating system service to get device phone#
        TelephonyManager tMgr = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);

        //message to be sent via SMS
        String txtMsg = "Congratulations on reaching your weight goal!!!!";

        //checks that permissions have been granted
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        //getting device phone #
        String phoneNum = tMgr.getLine1Number();
        //try catch block to send message via SmsManager after comparing weight to goal weight
        try {
            if(goalList.get(goalList.size()-1).getGoalType() == 0) {
                if(weightList.get(weightList.size()-1).getWeight() <= goalList.get(goalList.size()-1).getGoalWeight()) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNum, null, txtMsg, null, null);
                }
            } else {
                if(weightList.get(weightList.size()-1).getWeight() >= goalList.get(goalList.size()-1).getGoalWeight()) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNum, null, txtMsg, null, null);
                }
            }
        }
        catch (Exception e) {
            //if exception is thrown, permissions have not been granted
            Toast.makeText(getContext(), "Notifications not permitted", Toast.LENGTH_SHORT).show();
        }
    }
}

